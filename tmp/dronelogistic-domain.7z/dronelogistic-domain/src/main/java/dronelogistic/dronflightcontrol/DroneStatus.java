package dronelogistic.dronflightcontrol;

public enum DroneStatus {
    LOOKING_FOR_A_JOB, ROUTE_UPLOADED, UPLOAD_FAILED, READY_FOR_TAKE_OFF, HOUSTON_WE_HAVE_A_PROBLEM 
}
