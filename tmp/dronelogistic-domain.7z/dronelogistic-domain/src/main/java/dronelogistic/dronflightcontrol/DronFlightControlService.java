package dronelogistic.dronflightcontrol;

import dronelogistic.orderinformations.DeliveryAddress;

public interface DronFlightControlService {
    
    AvaliableDrones getAvaliableDrones();
    
    Drone reserveDrone(String droneTyp) throws DroneNotAvaliableException;
    
    Drone findDrone(Integer droneId) throws DroneNotFoundException;
    
    DeliveryRoute calculateDeliveryRoute(DeliveryAddress address);
    
}
