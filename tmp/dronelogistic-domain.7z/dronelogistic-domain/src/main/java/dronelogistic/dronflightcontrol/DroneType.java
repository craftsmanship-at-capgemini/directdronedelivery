package dronelogistic.dronflightcontrol;

public enum DroneType {
    SMALL_FOUR_ROTORS, BIG_SIX_ROTORS
}
