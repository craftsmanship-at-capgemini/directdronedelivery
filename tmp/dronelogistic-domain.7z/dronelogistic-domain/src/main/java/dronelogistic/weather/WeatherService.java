package dronelogistic.weather;

public interface WeatherService {
    
    Weather getActualWeather();
    
}
