package dronelogistic.comandcenter.businessrules;

public class ProfitabilityAndPriorityAcceptanceStrategy {
    
    public boolean isPositive(double profitability, double priority) {
        // TODO Auto-generated method stub
        return true;
    }
    
}
