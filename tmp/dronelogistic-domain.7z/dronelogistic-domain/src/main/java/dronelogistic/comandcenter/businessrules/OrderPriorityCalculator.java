package dronelogistic.comandcenter.businessrules;

import dronelogistic.orderinformations.ConsignmentInformation;
import dronelogistic.orderinformations.OrderAndCargoInformation;

public class OrderPriorityCalculator {
    
    public double evaluatePriority(OrderAndCargoInformation orderAndCargoInformation,
            ConsignmentInformation consignementInformation) {
        // TODO Auto-generated method stub
        return 0.0;
    }
    
}
