package dronelogistic.comandcenter.businessrules;

import dronelogistic.orderinformations.OrderAndCargoInformation;

public class PlaceOfDeliverySpecyfication {
    
    public boolean isAcceptable(OrderAndCargoInformation orderAndCargoInformation) {
        // TODO Auto-generated method stub
        return true;
    }
    
}
