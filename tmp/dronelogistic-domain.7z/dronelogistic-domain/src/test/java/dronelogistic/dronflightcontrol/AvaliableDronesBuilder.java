package dronelogistic.dronflightcontrol;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class AvaliableDronesBuilder {
    
    private static AtomicInteger nextDroneID = new AtomicInteger(0);
    
    private AvaliableDrones underConstruction = null;
    private List<DroneType> typicalDroneTypes = Arrays.asList(DroneType.SMALL_FOUR_ROTORS, DroneType.BIG_SIX_ROTORS);
    
    private AvaliableDronesBuilder() {
    }
    
    public static Drone newDrone(int droneID, DroneType droneType) {
        DroneStatus status = DroneStatus.LOOKING_FOR_A_JOB;
        return new Drone(droneID, DeliveryRoute.noDeliveryRouteUploaded(), status, droneType);
    }
    
    public static Drone newDrone(DroneType droneType) {
        DroneStatus status = DroneStatus.LOOKING_FOR_A_JOB;
        return new Drone(nextDroneID.incrementAndGet(), DeliveryRoute.noDeliveryRouteUploaded(), status, droneType);
    }
    
    public static Drone newDrone() {
        DroneType droneType = DroneType.SMALL_FOUR_ROTORS;
        DroneStatus status = DroneStatus.LOOKING_FOR_A_JOB;
        return new Drone(nextDroneID.incrementAndGet(), DeliveryRoute.noDeliveryRouteUploaded(), status, droneType);
    }
    
    public static AvaliableDronesBuilder anAvaliableDrones() {
        AvaliableDronesBuilder builder = new AvaliableDronesBuilder();
        builder.underConstruction = new AvaliableDrones(new ArrayList<DroneType>(), new HashMap<DroneType, Integer>());
        return builder;
    }
    
    public AvaliableDronesBuilder likeNoDronesAvaliable() {
        withDroneTypes(typicalDroneTypes);
        withNoDroneAvaliable();
        return this;
    }
    
    public AvaliableDronesBuilder but() {
        return this;
    }
    
    public AvaliableDronesBuilder withDroneTypes(List<DroneType> droneTypes) {
        underConstruction.droneTypes = droneTypes;
        return this;
    }
    
    public AvaliableDronesBuilder withDroneCounts(Map<DroneType, Integer> counts) {
        underConstruction.droneCounts = counts;
        return this;
    }
    
    public AvaliableDronesBuilder withDroneCount(DroneType droneTypes, int count) {
        underConstruction.droneCounts.put(droneTypes, count);
        return this;
    }
    
    public AvaliableDronesBuilder withDrone(Drone drone) {
        int count = underConstruction.droneCounts.get(drone.getType());
        underConstruction.droneCounts.put(drone.getType(), ++count);
        return this;
    }
    
    public AvaliableDronesBuilder withNoDroneAvaliable() {
        withDroneCounts(new HashMap<DroneType, Integer>());
        for (DroneType droneType : underConstruction.droneTypes) {
            withDroneCount(droneType, 0);
        }
        return this;
    }
    
    public AvaliableDrones build() {
        AvaliableDrones builded = underConstruction;
        underConstruction = new AvaliableDrones(Arrays.asList(DroneType.SMALL_FOUR_ROTORS, DroneType.BIG_SIX_ROTORS), new HashMap<DroneType, Integer>());
        return builded;
    }
    
}
