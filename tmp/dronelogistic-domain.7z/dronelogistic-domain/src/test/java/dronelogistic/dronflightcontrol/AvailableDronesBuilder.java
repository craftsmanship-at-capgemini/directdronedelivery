package dronelogistic.dronflightcontrol;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class AvailableDronesBuilder {
    
    private static AtomicInteger nextDroneID = new AtomicInteger(0);
    
    private AvaliableDrones underConstruction = null;
    private List<String> typicalDroneTypes = Arrays.asList("T4 v1", "T8 v1");
    
    private AvailableDronesBuilder() {
    }
    
    public static Drone newDrone(int droneID, String droneType) {
        return new Drone(droneID, droneType, null, null, DroneType.BIG_SIX_ROTORS);
    }
    
    public static Drone newDrone(String droneType) {
        return new Drone(nextDroneID.incrementAndGet(), droneType, null, null, DroneType.SMALL_FOUR_ROTORS);
    }
    
    public static Drone newDrone() {
        return new Drone(nextDroneID.incrementAndGet(), "T4 v1", null, null, DroneType.BIG_SIX_ROTORS);
    }
    
    public static AvailableDronesBuilder anAvaliableDrones() {
        AvailableDronesBuilder builder = new AvailableDronesBuilder();
        builder.underConstruction = new AvaliableDrones(new ArrayList<String>(), new HashMap<String, Integer>());
        return builder;
    }
    
    public AvailableDronesBuilder likeNoDronesAvaliable() {
        withDroneTypes(typicalDroneTypes);
        withNoDroneAvaliable();
        return this;
    }
    
    public AvailableDronesBuilder but() {
        return this;
    }
    
    public AvailableDronesBuilder withDroneTypes(List<String> droneTypes) {
        underConstruction.droneTypes = droneTypes;
        return this;
    }
    
    public AvailableDronesBuilder withDroneCounts(Map<String, Integer> counts) {
        underConstruction.droneCounts = counts;
        return this;
    }
    
    public AvailableDronesBuilder withDroneCount(String droneTypes, int count) {
        underConstruction.droneCounts.put(droneTypes, count);
        return this;
    }
    
    public AvailableDronesBuilder withDrone(Drone drone) {
        int count = underConstruction.droneCounts.get(drone.getDroneType());
        underConstruction.droneCounts.put(drone.getDroneType(), ++count);
        return this;
    }
    
    public AvailableDronesBuilder withNoDroneAvaliable() {
        withDroneCounts(new HashMap<String, Integer>());
        for (String droneType : underConstruction.droneTypes) {
            withDroneCount(droneType, 0);
        }
        return this;
    }
    
    public AvaliableDrones build() {
        AvaliableDrones builded = underConstruction;
        underConstruction = new AvaliableDrones(Arrays.asList("T4 v1", "T8 v1"), new HashMap<String, Integer>());
        return builded;
    }
    
}